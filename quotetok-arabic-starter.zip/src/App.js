import React, { useState } from 'react';
function App() { return <div className="text-center p-10">QuoteTok Arabic Starter</div>; }
export default App;